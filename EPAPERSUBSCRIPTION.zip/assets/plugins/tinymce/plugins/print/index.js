// Exports the "print" plugin for usage with module loaders
// Usage:
//   CommonJS:
//     require('tinymce/plugins/print')
//   ES2015:
//     import 'tinymce/plugins/print'
require('./plugin.js');