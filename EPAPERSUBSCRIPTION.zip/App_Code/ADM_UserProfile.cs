﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Security.Cryptography;
using System.Text;
using System.IO;
using System.DirectoryServices;

/// <summary>
/// Summary description for ADM_UserProfile
/// </summary>
public class ADM_UserProfile
{
    SqlConnection sCon = new SqlConnection(ConfigurationManager.ConnectionStrings["EPSConnectionString"].ToString());

    public ADM_UserProfile()
    {
        //
        // TODO: Add constructor logic here
        //
    }

    public int verifyLogin(string sUsername, string sPassword)
    {
        int nUserId = 0;
        try
        {
            SqlCommand cmd = new SqlCommand("SP_verifyLogin", sCon);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@Username", sUsername);
            cmd.Parameters.AddWithValue("@Password",(sPassword));
            sCon.Open();

            DataSet oDS = new DataSet();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(oDS);

            if (oDS != null && oDS.Tables[0] != null && oDS.Tables[0].Rows.Count > 0)
            {
                int nId = Convert.ToInt32(oDS.Tables[0].Rows[0]["ID"]);
                string sStatus = oDS.Tables[0].Rows[0]["Status"].ToString();
                if (nId > 0 && sStatus == "Active" && oDS.Tables[0].Rows[0]["LoginType"].ToString() == "LDAP")
                {
                    if (VerifyLoginLDAP(sUsername, sPassword))
                    {
                        nUserId = nId;
                    }
                    else
                    {
                        nUserId = 0;
                    }
                }
                else if (sStatus == "Active")
                {
                    nUserId = nId;
                }
            }
            cmd.Dispose();
            return nUserId;
        }
        catch (Exception ex)
        {
            return nUserId;
            //throw;
        }
        finally
        {
            sCon.Close();
            sCon.Dispose();
        }
    }

    public DataSet getUserProfile(int nUserId)
    {
        try
        {
            SqlCommand cmd = new SqlCommand("SP_getUserProfile", sCon);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@UserId", nUserId);
            sCon.Open();

            DataSet oDS = new DataSet();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(oDS);

            cmd.Dispose();
            return oDS;
        }
        catch (Exception ex)
        {
            throw;
        }
        finally
        {
            sCon.Close();
            sCon.Dispose();
        }
    }

    private bool VerifyLoginLDAP(string sUsername, string sPassword)
    {
        bool sResult = false;
        using (DirectoryEntry adsEntry = new DirectoryEntry(ConfigurationManager.AppSettings["ldap_path"], sUsername, sPassword))
        {
            using (DirectorySearcher adsSearcher = new DirectorySearcher(adsEntry))
            {
                adsSearcher.Filter = "(&(objectCategory=Person)(objectClass=user))";
                adsSearcher.Filter = "(sAMAccountName=" + sUsername + ")";

                try
                {
                    SearchResult adsSearchResult = adsSearcher.FindOne();
                    bool bSucceeded = true;
                    if (bSucceeded == true)
                    {
                        sResult = true;
                    }
                }
                catch (Exception ex)
                {
                    sResult = false;
                }
                finally
                {
                    adsEntry.Close();
                }
            }
        }
        return sResult;
    }

    public string Encrypt(string encryptString)
    {
        string EncryptionKey = "Daemon09";
        byte[] clearBytes = Encoding.Unicode.GetBytes(encryptString);
        using (Aes encryptor = Aes.Create())
        {
            Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
            encryptor.Key = pdb.GetBytes(32);
            encryptor.IV = pdb.GetBytes(16);
            using (MemoryStream ms = new MemoryStream())
            {
                using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateEncryptor(), CryptoStreamMode.Write))
                {
                    cs.Write(clearBytes, 0, clearBytes.Length);
                    cs.Close();
                }
                encryptString = Convert.ToBase64String(ms.ToArray());
            }
        }
        return encryptString;
    }

    public string Decrypt(string cipherText)
    {
        string EncryptionKey = "Daemon09";
        cipherText = cipherText.Replace(" ", "+");
        byte[] cipherBytes = Convert.FromBase64String(cipherText);
        using (Aes encryptor = Aes.Create())
        {
            Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
            encryptor.Key = pdb.GetBytes(32);
            encryptor.IV = pdb.GetBytes(16);
            using (MemoryStream ms = new MemoryStream())
            {
                using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateDecryptor(), CryptoStreamMode.Write))
                {
                    cs.Write(cipherBytes, 0, cipherBytes.Length);
                    cs.Close();
                }
                cipherText = Encoding.Unicode.GetString(ms.ToArray());
            }
        }
        return cipherText;
    }

    public DataTable getUserList(string sUserName, string sLoginType, string sFullName, string sStatus)
    {
        try
        {
            DataTable dtcomp = new DataTable();
            SqlCommand cmd = new SqlCommand("SP_getUserList", sCon);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@UserName", sUserName);
            cmd.Parameters.AddWithValue("@LoginType", sLoginType);
            cmd.Parameters.AddWithValue("@FullName", sFullName);
            cmd.Parameters.AddWithValue("@Status", sStatus);
            sCon.Open();

            DataSet oDSLogin = new DataSet();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(oDSLogin);

            if (oDSLogin != null && oDSLogin.Tables[0] != null && oDSLogin.Tables[0].Rows.Count > 0)
            {
                dtcomp = oDSLogin.Tables[0];
            }
            cmd.Dispose();
            return dtcomp;
        }
        catch
        {
            throw;
        }
        finally
        {
            sCon.Close();
            sCon.Dispose();
        }
    }

    public DataTable getUserDetails(string sUserId)
    {
        try
        {
            DataTable dt = new DataTable();
            SqlCommand cmd = new SqlCommand("SP_getUserDetails", sCon);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@UserId", sUserId);
            sCon.Open();

            DataSet oDS = new DataSet();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(oDS);

            if (oDS != null && oDS.Tables[0] != null && oDS.Tables[0].Rows.Count > 0)
            {
                dt = oDS.Tables[0];
            }
            cmd.Dispose();
            return dt;
        }
        catch
        {
            throw;
        }
        finally
        {
            sCon.Close();
            sCon.Dispose();
        }
    }

    public DataTable addNewUser(string sLoginType, string sUserName, string sPassword, string sFullName, string sStatus, int nUserId)
    {
        try
        {
            DataTable dt = new DataTable();
            SqlCommand cmd = new SqlCommand("SP_addNewUser", sCon);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@LoginType", sLoginType);
            cmd.Parameters.AddWithValue("@Username", sUserName);
            cmd.Parameters.AddWithValue("@Password", sPassword);
            cmd.Parameters.AddWithValue("@FullName", sFullName);
            cmd.Parameters.AddWithValue("@Status", sStatus);
            cmd.Parameters.AddWithValue("@UserId", nUserId);
            sCon.Open();

            DataSet oDS = new DataSet();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(oDS);

            if (oDS != null && oDS.Tables[0] != null && oDS.Tables[0].Rows.Count > 0)
            {
                dt = oDS.Tables[0];
            }
            cmd.Dispose();
            return dt;
        }
        catch
        {
            throw;
        }
        finally
        {
            sCon.Close();
            sCon.Dispose();
        }
    }

    public DataTable updateUserDetails(string sUserId, string sUserName, string sFullName, string sStatus, int nUpdatedBy)
    {
        try
        {
            DataTable dt = new DataTable();
            SqlCommand cmd = new SqlCommand("SP_updateUserDetails", sCon);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@UserId", sUserId);
            cmd.Parameters.AddWithValue("@Username", sUserName);
            cmd.Parameters.AddWithValue("@FullName", sFullName);
            cmd.Parameters.AddWithValue("@Status", sStatus);
            cmd.Parameters.AddWithValue("@UpdatedBy", nUpdatedBy);
            sCon.Open();

            DataSet oDS = new DataSet();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(oDS);

            if (oDS != null && oDS.Tables[0] != null && oDS.Tables[0].Rows.Count > 0)
            {
                dt = oDS.Tables[0];
            }
            cmd.Dispose();
            return dt;
        }
        catch
        {
            throw;
        }
        finally
        {
            sCon.Close();
            sCon.Dispose();
        }
    }

    public DataTable ResetUserPassword(string sUserId, string sPassword, int nUpdatedBy)
    {
        try
        {
            DataTable dt = new DataTable();
            SqlCommand cmd = new SqlCommand("SP_ResetUserPassword", sCon);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@UserId", sUserId);
            cmd.Parameters.AddWithValue("@Password", (sPassword));
            cmd.Parameters.AddWithValue("@UpdatedBy", nUpdatedBy);
            sCon.Open();

            DataSet oDS = new DataSet();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(oDS);

            if (oDS != null && oDS.Tables[0] != null && oDS.Tables[0].Rows.Count > 0)
            {
                dt = oDS.Tables[0];
            }
            cmd.Dispose();
            return dt;
        }
        catch
        {
            throw;
        }
        finally
        {
            sCon.Close();
            sCon.Dispose();
        }
    }


    public DataTable getUserPermissionList(int nUserId)
    {
        try
        {
            DataTable dt = new DataTable();
            SqlCommand cmd = new SqlCommand("SP_getUserPermissionList", sCon);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@UserId", nUserId);
            sCon.Open();

            DataSet oDS = new DataSet();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(oDS);

            if (oDS != null)
            {
                if (oDS.Tables[0] != null)
                {
                    dt = oDS.Tables[0];
                }
            }
            cmd.Dispose();
            return dt;
        }
        catch
        {
            throw;
        }
        finally
        {
            sCon.Close();
            sCon.Dispose();
        }
    }

    public DataTable updateUserPermission(int nUserId, string sCompId, int nSBUId, string sPermission, int nUpdatedBy)
    {
        try
        {
            DataTable dt = new DataTable();
            SqlCommand cmd = new SqlCommand("SP_updateUserPermission", sCon);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@UserId", nUserId);
            cmd.Parameters.AddWithValue("@CompId", sCompId);
            cmd.Parameters.AddWithValue("@SBUId", nSBUId);
            cmd.Parameters.AddWithValue("@Permission", sPermission);
            cmd.Parameters.AddWithValue("@UpdatedBy", nUpdatedBy);
            sCon.Open();

            DataSet oDS = new DataSet();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(oDS);

            if (oDS != null && oDS.Tables[0] != null && oDS.Tables[0].Rows.Count > 0)
            {
                dt = oDS.Tables[0];
            }
            cmd.Dispose();
            return dt;
        }
        catch
        {
            throw;
        }
        finally
        {
            sCon.Close();
            sCon.Dispose();
        }
    }
}