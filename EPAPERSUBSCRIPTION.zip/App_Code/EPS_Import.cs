﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for EPS_Import
/// </summary>
public class EPS_Import
{
    SqlConnection sCon = new SqlConnection(ConfigurationManager.ConnectionStrings["EPSConnectionString"].ToString());

    public EPS_Import()
    {
        //
        // TODO: Add constructor logic here
        //
    }

    //Import Data
    //////////////////////////////////////////
    ///
    public DataTable addnewEpaperSubscriber(string sEmailMobile, string sPackageName, int nTitleCount, DateTime saleDate, double amount, double discount, double netAmountINR, double netAmountUSD, double conversionRate, double billingAmountINR, string currency, string Source, string via, string type, string city, string country, int UserId)
    {
        DataTable dt = new DataTable();
        try
        {
            SqlCommand cmd = new SqlCommand("SP_addNewEpaperSubscriber", sCon);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@EmailMobile", sEmailMobile);
            cmd.Parameters.AddWithValue("@PackageName", (sPackageName));
            cmd.Parameters.AddWithValue("@TitleCount", nTitleCount);
            cmd.Parameters.AddWithValue("@Saledate", saleDate);
            cmd.Parameters.AddWithValue("@Amount", amount);
            cmd.Parameters.AddWithValue("@Discount", discount);
            cmd.Parameters.AddWithValue("@NetAmountINR", netAmountINR);
            cmd.Parameters.AddWithValue("@NetAmountUSD", netAmountUSD);
            cmd.Parameters.AddWithValue("@ConversionRate", conversionRate);
            cmd.Parameters.AddWithValue("@BillingAmountINR", billingAmountINR);
            cmd.Parameters.AddWithValue("@Currency", currency);
            cmd.Parameters.AddWithValue("@Source", Source);
            cmd.Parameters.AddWithValue("@Via", via);
            cmd.Parameters.AddWithValue("@Type", type);
            cmd.Parameters.AddWithValue("@City", city);
            cmd.Parameters.AddWithValue("@Country", country);
            cmd.Parameters.AddWithValue("@UserId", UserId);

            sCon.Open();

            DataSet oDS = new DataSet();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(oDS);

            if (oDS != null && oDS.Tables[0] != null )
            {
                dt = (oDS.Tables[0]);
            }
            cmd.Dispose();
            return dt;
        }
        catch (Exception ex)
        {
            return dt;
            //throw;
        }
        finally
        {
            sCon.Close();
            sCon.Dispose();
        }
    }

    public DataTable getPackageList()
    {
        DataTable dt = new DataTable();
        try
        {
            SqlCommand cmd = new SqlCommand("SP_getPackageList", sCon);
            cmd.CommandType = CommandType.StoredProcedure;
            sCon.Open();

            DataSet oDS = new DataSet();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(oDS);

            if (oDS != null && oDS.Tables[0] != null)
            {
                dt = (oDS.Tables[0]);
            }
            cmd.Dispose();
            return dt;
        }
        catch (Exception ex)
        {
            return dt;
            //throw;
        }
        finally
        {
            sCon.Close();
            sCon.Dispose();
        }
    }

    public DataTable getEpaperSubscriberlist(DateTime dtFromDate, DateTime dtToDate,string sEmailMobile, int nPackageId)
    {
        DataTable dt = new DataTable();
        try
        {
            SqlCommand cmd = new SqlCommand("SP_getEPaperSubscriberlist", sCon);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@FromDate", dtFromDate);
            cmd.Parameters.AddWithValue("@ToDate", dtToDate);
            cmd.Parameters.AddWithValue("@EmailPhone", sEmailMobile);
            cmd.Parameters.AddWithValue("@PackageId", (nPackageId));

            sCon.Open();

            DataSet oDS = new DataSet();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(oDS);

            if (oDS != null && oDS.Tables[0] != null)
            {
                dt = (oDS.Tables[0]);
            }
            cmd.Dispose();
            return dt;
        }
        catch (Exception ex)
        {
            return dt;
            //throw;
        }
        finally
        {
            sCon.Close();
            sCon.Dispose();
        }
    }
}